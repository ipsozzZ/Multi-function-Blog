<?php
/**
 * Created by PhpStorm.
 * User:  pso318
 * Date: 2018/6/5
 * Time: 16:19
 */

namespace app\admin\model;


use think\Model;

class Banner extends Model
{

}