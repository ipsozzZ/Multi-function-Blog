<?php
/**
 * Created by PhpStorm.
 * User:  pso318
 * Date: 2018/7/30
 * Time: 18:42
 */

return [
    'view_replace_str'  =>  [
        '__INDEX__'=>'/static/index',
    ]
];